package com.example.somnolence.data.models

data class Wind(
    val deg: Int,
    val gust: Double,
    val speed: Double
)