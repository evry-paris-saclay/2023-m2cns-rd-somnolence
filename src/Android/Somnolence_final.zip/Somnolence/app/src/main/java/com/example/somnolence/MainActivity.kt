package com.example.somnolence


import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.somnolence.databinding.ActivityMainBinding
import com.example.somnolence.utils.RetrofitInstance
import com.jakewharton.threetenabp.AndroidThreeTen
import kotlinx.coroutines.launch
import kotlinx.coroutines.channels.Channel
import org.threeten.bp.LocalDateTime
import com.example.somnolence.CameraXViewModel
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.activity.viewModels
import androidx.camera.core.ImageProxy
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.example.somnolence.facedetector.FaceBox
import com.example.somnolence.facedetector.Drowsy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import kotlinx.coroutines.CoroutineScope
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var cameraSelector: CameraSelector
    private lateinit var processCameraProvider: ProcessCameraProvider
    private lateinit var cameraPreview: Preview
    private lateinit var imageAnalysis: ImageAnalysis
    private lateinit var faceDrowsiness: Drowsy
    var camera=0
    var resultHeartRate = 0

    val TAG="camera"
    private val cameraXViewModel = viewModels<CameraXViewModel>()

    private val requestBluetoothPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                // Bluetooth permission granted, check location permission
                requestCameraPermissions()
            } else {
                // Bluetooth permission denied, handle accordingly
            }
        }
    private val requestCameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                // Bluetooth permission granted, check location permission
                requestLocationPermissions()
            } else {
                // Bluetooth permission denied, handle accordingly
            }
        }

    private val requestLocationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                // Location permission granted, start using MiBand
                startMiBand()
            } else {
                // Location permission denied, handle accordingly
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AndroidThreeTen.init(this);
        faceDrowsiness = Drowsy()


        if (checkBluetoothPermissions() && checkLocationPermission()) {
            // Permissions granted, start using MiBand
            startMiBand()
        } else {
            // Request Bluetooth permission
            requestBluetoothPermissions()
        }
    }

    private fun checkBluetoothPermissions(): Boolean {
        return (ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.BLUETOOTH_CONNECT
        ) == PackageManager.PERMISSION_GRANTED)
    }

    private fun checkCameraPermissions(): Boolean {
        return (ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED)
    }

    private fun checkLocationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED)
        } else {
            true // For versions below Android 12, no fine location permission is needed
        }
    }

    private fun requestBluetoothPermissions() {
        requestBluetoothPermissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
    }

    private fun requestCameraPermissions() {
        requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun requestLocationPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestLocationPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        } else {
            // For versions below Android 12, no fine location permission is needed
            // Directly proceed to start using MiBand
            startMiBand()
        }
    }

    private fun startMiBand() {
        val macAddress = "EF:76:31:91:E0:78"
        val key = "61442785db7ae989c3cfb6ab9aee07a0"
        val since = LocalDateTime.now().minusMinutes(1)
        val apiKey = "8214d0eb7505a5f001ebd1cc67895323"
        val city = "Paris" // Remplacez par la ville de votre choix
        val channel = Channel<Int>()


        lifecycleScope.launch {
            try {
                System.out.println("hahaha")
                val miBand = MiBand(this@MainActivity, BluetoothAdapter.getDefaultAdapter().getRemoteDevice(macAddress), key, this@MainActivity)
                miBand.connect()
                System.out.println("hihihi")
                // Perform other MiBand operations here
                // Set up a channel to receive real-time heart rate data

                // Start receiving real-time heart rate data
                System.out.println("Fetch data since " + since)
                System.out.println("taatat")

                    miBand.startRealtimeHeartRate(channel)


                // Continue with other tasks here

            } catch (e: Exception) {
                // Handle exceptions here
            }
        }

        lifecycleScope.launch {
            System.out.println("l'autre truc")
            while (true) {
                val newHeartRate = channel.receive()
                resultHeartRate=newHeartRate
                binding.heartRateTextView.text="Heartrate : "+newHeartRate+" bpm"
                System.out.println("est ce que ici on l'a "+newHeartRate);
                if(resultHeartRate!=0 && resultHeartRate<=65 && (!checkCameraPermissions()||camera==0)){
                    binding.resultatTextView.text = "Somnolent"
                }
                if(resultHeartRate!=0 && resultHeartRate>=66 && (!checkCameraPermissions()||camera==0)){
                    binding.resultatTextView.text = "Non Somnolent"
                }
                if(resultHeartRate==0 && (!checkCameraPermissions()||camera==0)){
                    binding.resultatTextView.text = "Aucun capteur disponible"
                }

            }
        }
        //temperature
        lifecycleScope.launch {
          val response=  try {
              RetrofitInstance.api.getCurrentWeather(
                  "Paris",
                  "metric",
                  "8214d0eb7505a5f001ebd1cc67895323")
            } catch (e: Exception) {
                // Gérer les erreurs, par exemple si la clé API est incorrecte
              return@launch
            }
            if (response.isSuccessful && response.body() != null) {
                val data = response.body()!!
                System.out.println("La temperature est "+data.main.temp.toInt()+"°C")
                binding.temperatureTextView.text ="Temperature : "+data.main.temp.toInt()+"°C"
            }
        }
        // on lance la camera
        lifecycleScope.launch {
            cameraSelector =
                CameraSelector.Builder().requireLensFacing(CameraSelector.LENS_FACING_FRONT).build()
            cameraXViewModel.value.processCameraProvider.observe(this@MainActivity) { provider ->
                processCameraProvider = provider
                bindCameraPreview()
                bindInputAnalyser()
            }
        }

    }
    private fun bindCameraPreview() {
        cameraPreview = Preview.Builder()
            .setTargetRotation(binding.previewView.display.rotation)
            .build()
        cameraPreview.setSurfaceProvider(binding.previewView.surfaceProvider)
        try {
            processCameraProvider.bindToLifecycle(this, cameraSelector, cameraPreview)
        } catch (illegalStateException: IllegalStateException) {

            Log.e(TAG, illegalStateException.message ?: "IllegalStateException")
        } catch (illegalArgumentException: IllegalArgumentException) {
            Log.e(TAG, illegalArgumentException.message ?: "IllegalArgumentException")
        }
    }

    private fun bindInputAnalyser() {
        val detector = FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
                .enableTracking()
                .build()
        )
        imageAnalysis = ImageAnalysis.Builder()
            .setTargetRotation(binding.previewView.display.rotation)
            .build()

        val cameraExecutor = Executors.newSingleThreadExecutor()

        imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
            processImageProxy(detector, imageProxy)
        }

        try {
            processCameraProvider.bindToLifecycle(this, cameraSelector, imageAnalysis)
        } catch (illegalStateException: IllegalStateException) {
            Log.e(TAG, illegalStateException.message ?: "IllegalStateException")
        } catch (illegalArgumentException: IllegalArgumentException) {
            Log.e(TAG, illegalArgumentException.message ?: "IllegalArgumentException")
        }
    }

    @SuppressLint("UnsafeOptInUsageError")
    private fun processImageProxy(detector: FaceDetector, imageProxy: ImageProxy) {
        val inputImage =
            InputImage.fromMediaImage(imageProxy.image!!, imageProxy.imageInfo.rotationDegrees)
        detector.process(inputImage).addOnSuccessListener { faces ->
            binding.graphicOverlay.clear()

            faces.forEach { face ->
                 camera=1
                if (faceDrowsiness.isDrowsy(face)) {
                    // Faites quelque chose si le visage est somnolent
                    // Par exemple, affichez un avertissement, déclenchez une action, etc.
                    System.out.println("Le visage est somnolent !")

                       if (resultHeartRate<=65 && resultHeartRate!=0) { binding.resultatTextView.text = "Somnolent"
                        }

                       if(resultHeartRate==0){
                           binding.resultatTextView.text = "Somnolent"
                       }
                }else{

                    if (resultHeartRate<=65 && resultHeartRate!=0) { binding.resultatTextView.text = "Somnolent"
                    }else {
                        System.out.println("Le visage non !")
                        binding.resultatTextView.text = "Non Somnolent"
                    }

                }

                val faceBox = FaceBox(binding.graphicOverlay, face, imageProxy.image!!.cropRect)
                binding.graphicOverlay.add(faceBox)
            }
            camera=0
        }.addOnFailureListener {
            it.printStackTrace()
        }.addOnCompleteListener {
            imageProxy.close()
        }
    }

}
