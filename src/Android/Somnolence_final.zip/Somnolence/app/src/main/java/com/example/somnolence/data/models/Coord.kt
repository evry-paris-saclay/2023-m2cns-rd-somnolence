package com.example.somnolence.data.models

data class Coord(
    val lat: Double,
    val lon: Double
)