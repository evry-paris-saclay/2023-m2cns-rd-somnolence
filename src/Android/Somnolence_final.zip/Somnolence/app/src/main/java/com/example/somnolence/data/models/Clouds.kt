package com.example.somnolence.data.models

data class Clouds(
    val all: Int
)