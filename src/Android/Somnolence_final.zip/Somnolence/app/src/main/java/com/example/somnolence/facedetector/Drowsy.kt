package com.example.somnolence.facedetector

import com.google.mlkit.vision.face.Face
import java.util.ArrayDeque

class Drowsy {
    private val DROWSINESS_THRESHOLD = 0.5f
    private val MAX_HISTORY = 10

    var lastCheckedAt: Long = 0
    private val history = ArrayDeque<Boolean>()

    fun isDrowsy(face: Face?): Boolean {
        var isDrowsy = true
        lastCheckedAt = System.currentTimeMillis()

        if (face?.leftEyeOpenProbability == null || face.rightEyeOpenProbability == null) {
            return false
        }

        if (face.leftEyeOpenProbability!! < DROWSINESS_THRESHOLD
            && face.rightEyeOpenProbability!! < DROWSINESS_THRESHOLD
        ) {
            history.addLast(true)
        } else {
            history.addLast(false)
        }

        if (history.size > MAX_HISTORY) {
            history.removeFirst()
        }

        if (history.size == MAX_HISTORY) {
            isDrowsy = history.all { it }
        } else {
            return false
        }

        return isDrowsy
    }
}
