from owlready2 import *
from datetime import timedelta

onto = get_ontology("http://test.org/onto.owl")

#declaration of classes and attributs
with onto:
    class Driver(Thing): pass
    class nbDrowsinessSigne ( Driver >> int, FunctionalProperty):pass
    class defaultNbDrowsinessSigne ( Driver >> int, FunctionalProperty):pass    
    class resultHeartRate (Driver >> float, FunctionalProperty):pass
    class resultCamera (Driver >> float, FunctionalProperty):pass
    class stateDriver (Driver >> int, FunctionalProperty):pass
    class startDate (Driver >> datetime.date, FunctionalProperty):pass
    class startTime (Driver >> datetime.time, FunctionalProperty):pass

    class Sensor(Thing): pass
    class stateSensor (Sensor >> str, FunctionalProperty):pass
    class brand(Sensor >> str, FunctionalProperty):pass
    class Camera (Sensor):pass
    class HeartRate (Sensor):pass

    class Driving(Thing): pass
    class hourDriving (Driving >> datetime.time, FunctionalProperty):pass
    class dateDriving (Driving >> str, FunctionalProperty):pass
    class dayDriving (Driving >> str, FunctionalProperty):pass
    
    class Event(Thing): pass 
    
    class DangerousHour(Event):pass
    class hourEvent (DangerousHour >> datetime.time, FunctionalProperty):pass
    
    class DangerousDate(Event):pass
    class dateEvent (DangerousDate >> datetime.date, FunctionalProperty):pass
    
    class DangerousDay(Event):pass
    class dayEvent (DangerousDay >> str, FunctionalProperty):pass
    
    class Environment(Thing): pass
    class temperature (Environment >> float, FunctionalProperty):pass
    class weatherState (Environment >> str, FunctionalProperty):pass
    
    AllDisjoint([Driver, Sensor, Event,Driving,Environment])


#declaration of relation
with onto:
    class monitoredBy(ObjectProperty, FunctionalProperty):
        domain = [Driver]
        range = [Sensor] 
        
    class perform(ObjectProperty, FunctionalProperty):
        domain = [Driver]
        range = [Driving]
        
    class impactedBy(ObjectProperty, FunctionalProperty):
        domain = [Driving]
        range = [Event] 
        
    class isPerformedIn(ObjectProperty, FunctionalProperty):
        domain = [Driving]
        range = [Environment]


with onto:
    rule1 = Imp()
    rule1.set_as_rule("""Driver(?x),Environment(?w),temperature(?w,?y),lessThanOrEqual(?y,20) -> defaultNbDrowsinessSigne(?x,6)""")
    rule2 = Imp()
    rule2.set_as_rule("""Driver(?x),Environment(?w),weatherState(?w,"pluvieux") -> defaultNbDrowsinessSigne(?x,6)""")
    rule3 = Imp()
    rule3.set_as_rule("""Driver(?x),Environment(?w),weatherState(?w,"neigeux") -> defaultNbDrowsinessSigne(?x,6)""")




